import cv2
import numpy as np
import parameters
import time


def gammaCorrection(gamma,img_original):
    ## [changing-contrast-brightness-gamma-correction]
    lookUpTable = np.empty((1,256), np.uint8)
    for i in range(256):
        lookUpTable[0,i] = np.clip(pow(i / 255.0, gamma) * 255.0, 0, 255)

    res = cv2.LUT(img_original, lookUpTable)
    ## [changing-contrast-brightness-gamma-correction]
    return res

def CaB(alpha, beta, img):
    # change the contrast and brightness of image
    blank = np.zeros(img.shape, img.dtype)
    # dst = alpha * img + beta * blank
    dst = cv2.addWeighted(img, alpha, blank,0, beta)
    return dst

def onmouse(event,x,y,flags,param):
    # Capture the left mouse button behavior to get the corner coordinates
    global squ,allf
    if event==cv2.EVENT_LBUTTONDOWN:
        print(x,y)
        squ.append((x,y))
        #print (squ)
    if len(squ)==7: # there are 7 corners for three face
        allf=squ

def getcolor(p,hsv):
    #Decide the color of a facelet by its hsv value.
    sz = 5 #measuring range
    p = p.astype(np.uint16)
    area = hsv[p[1] - sz:p[1] + sz, p[0] - sz:p[0] + sz] # the measuring range is 10*10
    median = np.sum(area, axis=(0, 1)) / sz / sz / 4 # the average hsv value of the measuting range

    hue, sat, val = median
    if sat <= parameters.wsat and val >= parameters.wval:
        return median, 'white','U' # white is at the up side
    elif parameters.lorange <= hue < parameters.horange:
        return median, 'orange','B' # orange is at back side
    elif parameters.horange <= hue < parameters.hyellow:
        return median, 'yellow','D'# yellow is at down side
    elif parameters.hyellow <= hue < parameters.hgreen:
        if sat < 100:
            return median, 'white','U'
        else:
            return median, 'green','L'# green is at left side
    elif parameters.hgreen <= hue < parameters.hblue:
        if sat < 150:
            return median, 'white','U'
        else:
            return median, 'blue','R' # blue is at right side
    else:
        return median, 'red','F' # red is at front side

def display_colorname(bgrcap,p,hsv,colour,dcolour):
    #Display the colornames on the webcam picture.
    p = p.astype(np.uint16)
    if p[0] == 150 and p[1] == 150: # the middle facelet was corvered by the supporter, thus the colour need to be set
        col = colour
        dcol = dcolour # dcolour is depends on the preset position of rubik's cube. for exampel. if the face of red colour is the in the front, then F represent red.
    else:
        _, col, dcol = getcolor(p,hsv)

    if col in ('blue', 'green', 'red'):
        txtcol = (255, 255, 255)
    else:
        txtcol = (0, 0, 0)
    font = cv2.FONT_HERSHEY_SIMPLEX
    ts = cv2.getTextSize(col, font, 0.4, 1)[0]
    cv2.putText(bgrcap, col, tuple(p - (ts[0] // 2, -ts[1] // 2)), font, 0.4, txtcol, 1)
    return dcol

def coordinate(img): # set a new window for getting coordinates
    cv2.namedWindow("img",cv2.WINDOW_NORMAL)  # creat window
    cv2.setMouseCallback("img",onmouse,0) # callback window
    cv2.imshow("img",img) # show image

def array(point): #from list to array
    points=[]
    for i in range(len(point)):
        points.append(np.asarray(point[i]))
    return points


def get_downcamera():
    global squ,allf

    cap=cv2.VideoCapture(1)
    #img = cv2.imread('dcube.jpg')

    centlist=array([(50,50),(150,50),(250,50),(50,150),(150,150),(250,150),(50,250),(150,250),(250,250)]) # the center coordinates of each face after perspective transform
    allf=[(1590,2893), (2507, 2450), (654, 2609), (1573, 1951), (701, 1633), (1448, 913), (2249, 1504)]  # the preset corner coordinates for 3 face
    dsquares=array([allf[1],allf[0],allf[3],allf[2]]) # four corner coordinates for one face
    lsquares=array([allf[4],allf[5],allf[2],allf[3]])
    rsquares=array([allf[5],allf[6],allf[3],allf[1]])
    squ=[]
    #the paramaters for gamma correction and brightness and contrast#
    dgamma=parameters.dgamma
    lgamma=parameters.dlgamma
    rgamma=parameters.drgamma
    dalpha=parameters.dalpha
    lalpha=parameters.dlalpha
    ralpha=parameters.dralpha
    dbeta=parameters.dbeta
    lbeta=parameters.dlbeta
    rbeta=parameters.drbeta

    while 1:


        _,img = cap.read()
        try:
            cv2.imshow('DWebcam',img)
        except:
            print('fail to read the down camera')
            break


        k = cv2.waitKey(5) & 0xFF

        if k == ord('d'): #get the coordinate of face
            squ=[]
            pic = img
            coordinate(pic)

        if k == ord('h'): #update the new corner coordinates data
            dsquares=array([allf[1],allf[0],allf[3],allf[2]])
            lsquares=array([allf[4],allf[5],allf[2],allf[3]])
            rsquares=array([allf[5],allf[6],allf[3],allf[1]])

        if k == ord('b'): # change the brightness(beta) and contrast(alpha) of the face image
            # the name of each face here is 'dl' for donw left , 'dr' for down right, 'd' for down
            # get the alpha and beta value of eache face by the input
            print('face name:')
            a=input()
            if a=='dl':
                print('down left alpha =')
                a=input()
                try:
                    lalpha=float(a)
                except:
                    print('float')
                print('down left beta =')
                a=input()
                try:
                    lbeta=float(a)
                except:
                    print('float')
            elif a=='dr':
                print('down right alpha =')
                a=input()
                try:
                    ralpha=float(a)
                except:
                    print('float')
                print('down right beta =')
                a=input()
                try:
                    rbeta=float(a)
                except:
                    print('float')
            elif a=='d':
                print('down alpha =')
                a=input()
                try:
                    dalpha=float(a)
                except:
                    print('float')
                print('down beta =')
                a=input()
                try:
                    dbeta=float(a)
                except:
                    print('float')
            else :
                print('three facets: dl,dr,d')
        if k == ord('g'): # change the gamma of gamma correction for each face
            # the name of each face here is 'dl' for donw left , 'dr' for down right, 'd' for down
            # get the gamma value of eache face by the input
            print('face name:')
            a=input()
            if a=='dl':
                print('down left gamma =')
                gamma=input()
                try:
                    lgamma=float(gamma)
                except:
                    print('float')
            elif a=='dr':
                print('down right gamma =')
                gamma=input()
                try:
                    rgamma=float(gamma)
                except:
                    print('float')
            elif a=='d':
                print('down gamma =')
                gamma=input()
                try:
                    dgamma=float(gamma)
                except:
                    print('float')
            else :
                print('three facets: dl,dr,d')
        if k == ord('x'):
            break

        pts2 = np.float32([[0,0],[300,0],[0,300],[300,300]]) # coordinates of corner of each face after perspective transform
        slist = [dsquares,lsquares,rsquares] # coordinates before perspective transform for three face
        alpha = [dalpha,lalpha,ralpha]
        beta = [dbeta,lbeta,rbeta]
        gamma = [dgamma, lgamma, rgamma]
        hsvlist=[]
        dstlist=[]
        pdstlist=[]
        a=0

        for i in slist:
            pts1 = np.float32(i)
            M = cv2.getPerspectiveTransform(pts1,pts2) # get the perspective transform matrix to transform from shape pts1 to shape pts2
            dst = cv2.warpPerspective(img,M,(300,300)) # transform the image by perpective transform matrix M. (300,300)is the size of the output image
            dstlist.append(dst)
            cabdst=CaB(alpha[a],beta[a],dstlist[a]) #change the brightness and contrast of the image
            gamdst=gammaCorrection(gamma[a],cabdst) #use the gamma correction to correct the image
            pdstlist.append(gamdst)
            hsv = cv2.cvtColor(gamdst, cv2.COLOR_BGR2HSV) # convert from RGB colour space to HSV colour space
            hsvlist.append(hsv)
            a+=1

        midcolour={'colour':['yellow','orange','green'],'position':['D','B','L']}
        facet=['D','B','L']
        col={'D':[],'B':[],'L':[]}
        for i in centlist:
            for j in range(3):
                col[facet[j]].append(display_colorname(pdstlist[j], i, hsvlist[j],midcolour['colour'][j],midcolour['position'][j]))#get the colour name and display the colour name

        parameters.downface_col = col[facet[0]]+col[facet[2]]+col[facet[1]] # get the colour of three face as a list

        for i in range(3):
            cv2.imshow(facet[i],pdstlist[i]) # show the image of each face


    cap.release()

    cv2.destroyAllWindows()

#get_downcamera()
