####parameters ###
# The parameters are used by functions in downcamera.py and upcamera.py and solution.py

# default values for the parameters

# Thsese parameters depend on the actually used cube colors and the lab lightning conditions
lorange = 6  # lowest allowed hue for color orange
horange = 23  # highest allowed hue for color orange
hyellow = 50  # highest allowed hue for color yellow
hgreen = 100  # highest allowed hue for color green
hblue = 160  # highest allowed hue for color blue
wval= 150  #lowest allowed value for white
wsat= 60   #highest allowed saturation for white


# The colors of a cube face are stored here
downface_col = []   # the colors of three cube face from the downcamera
upface_col = []     # the colors of three cube face from the upcamera


dgamma=1
dlgamma=1
drgamma=1
dalpha=1
dlalpha=1.1
dralpha=1
dbeta=0
dlbeta=0
drbeta=0
ugamma=1
ulgamma=1
urgamma=1
ualpha=1
ulalpha=1.2
uralpha=1.3
ubeta=0
ulbeta=0
urbeta=-40
