import upcamera
import downcamera
import threading
import parameters
from collections import Counter
import kociemba
import time


def poiu1():
    thr = threading.Thread(target=upcamera.get_upcamera, args=())
    thr.start()

def poiu2():
    thr1 = threading.Thread(target=downcamera.get_downcamera, args=())
    thr1.start()


poiu1()
time.sleep(0.5)
poiu2()

#thr = threading.Thread(target=upcamera.get_upcamera, args=())
#thr.start()
#thr1 = threading.Thread(target=upcamera.get_upcamera, args=())
#thr1.start()
result = ''
#str ='URRBULBDRBFBFRRLLFULDLFDFFBRUDBDBFRLRDLRLUUUDUDFUBFDBL'

while 1:
    cube_col=parameters.upface_col+parameters.downface_col
    print(cube_col)
    if len(cube_col) == 54:
        count = Counter(cube_col)
        if count['F'] == count['L'] == count['R'] == count['B'] == count['U'] == count['D'] == 9:
            str = "".join(cube_col)
            print (str)
            if str == 'UUUUUUUUURRRRRRRRRFFFFFFFFFDDDDDDDDDLLLLLLLLLBBBBBBBBB':
                break
            else:
                try:
                    result = kociemba.solve(str)
                    print(result)
                except:
                    print('Failed to solve the cube')

                with open('theSolution.txt', "r+") as f:
                    data=f.readlines()
                    data[0]=result+'\n'
                    f.close()
                with open('theSolution.txt', "w+") as f:
                    f.writelines(data)
                    f.close()
                time.sleep(10)
        else:
            str = "".join(cube_col)
            print (str)
