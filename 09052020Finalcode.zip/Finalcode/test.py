import upcamera
import downcamera
import threading
import vision_params
from collections import Counter
import kociemba
import time
str ='FLDUUURLFUBLURRURBBFRRFRRFBDDLLDBUUUDLDDLFLDFBBLDBBRFF'
try:
    result = kociemba.solve(str)
except:
    print('Failed to solve the cube')
print(result)
   

with open('theSolution.txt', "r+") as f:
    data=f.readlines()
    data[0]=result+'\n'
    f.close()
with open('theSolution.txt', "w+") as f:    
    f.writelines(data)
    f.close()
