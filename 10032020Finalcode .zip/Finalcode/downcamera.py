import cv2
#from matplotlib import pyplot as plt
import numpy as np
import vision_params
#import threading
import time
#from playsound import playsound

def onmouse(event,x,y,flags,param):
    global squ,allf
    if event==cv2.EVENT_LBUTTONDOWN:
        print(x,y)
        squ.append((x,y))
        print (squ)
    if len(squ)==7:
        allf=squ

def getcolor(p,hsv):
    #Decide the color of a facelet by its h value (non white) or by s and v (white).
    sz = 5
    p = p.astype(np.uint16)
    rect = hsv[p[1] - sz:p[1] + sz, p[0] - sz:p[0] + sz]
    median = np.sum(rect, axis=(0, 1)) / sz / sz / 4
    #print (median)
    mh, ms, mv = median
    if ms <= vision_params.sat_W and mv >= vision_params.val_W:
        return median, 'white','U'
    elif vision_params.orange_L <= mh < vision_params.orange_H:
        return median, 'orange','B'
    elif vision_params.orange_H <= mh < vision_params.yellow_H:
        return median, 'yellow','D'
    elif vision_params.yellow_H <= mh < vision_params.green_H:
        if ms < 100:
            return median, 'white','U'  # green saturation is always higher
        else:
            return median, 'green','L'
    elif vision_params.green_H <= mh < vision_params.blue_H:
        if ms < 150:
            return median, 'white','U'  # blue saturation is always higher
        else:
            return median, 'blue','R'
    else:
        return median, 'red','F'

def display_colorname(bgrcap,p,hsv,colour,dcolour):
    #Display the colornames on the webcam picture.
    p = p.astype(np.uint16)
    if p[0] == 150 and p[1] == 150:
        col = colour
        dcol = dcolour
    else:
        _, col, dcol = getcolor(p,hsv)

    if col in ('blue', 'green', 'red'):
        txtcol = (255, 255, 255)
    else:
        txtcol = (0, 0, 0)
    font = cv2.FONT_HERSHEY_SIMPLEX
    tz = cv2.getTextSize(col, font, 0.4, 1)[0]
    cv2.putText(
        bgrcap, col, tuple(p - (tz[0] // 2, -tz[1] // 2)), font, 0.4, txtcol, 1)
    return dcol

def coordinate(img):
    cv2.namedWindow("img",cv2.WINDOW_NORMAL)  # creat window
    cv2.setMouseCallback("img",onmouse,0) # 回调绑定窗口
    cv2.imshow("img",img) # show image

def array(point): #from list to array
    points=[]
    for i in range(len(point)):
        points.append(np.asarray(point[i]))
    return points

def seven_array(corner): # model1 calculate the coordinate
    dleft1=np.asarray(corner[0])
    dright1=np.asarray(corner[1])
    dleft2=np.asarray(corner[2])
    dright2=np.asarray(corner[3])
    magnitude=np.linalg.norm((dleft1-dleft2))
    lleft2=np.asarray((int(dleft2[0]),int(dleft2[1]-magnitude)))
    lright2=np.asarray((int(dright2[0]),int(dright2[1]-magnitude)))
    rright2=np.asarray((int(dright1[0]),int(dright1[1]-magnitude)))
    #print([dleft1,dright1,dleft2,dright2,lleft2,lright2,rright2,magnitude])
    array=[dleft1,dright1,dleft2,dright2,lleft2,lright2,rright2,magnitude]
    return array



def get_downcamera():
    global squ,allf
    #img = cv2.imread('cube1.jpg')
    #leftcamera=1
    cap=cv2.VideoCapture(0)
    #cap.set(3,1280)
    #cap.set(4,720)

    dsquares=array([(133,350),(307,350),(468,350),(550,350)])
    lsquares=array([(133,350),(307,350),(468,350),(550,350)])
    rsquares=array([(133,350),(307,350),(468,350),(550,350)])
    centlist=array([(50,50),(50,150),(50,250),(150,50),(150,150),(150,250),(250,50),(250,150),(250,250)])

    squ=[]
    allf=[]
    dcolours=[]
    dlcolours=[]
    drcolours=[]

    time.sleep(10)

    while 1:


        _,img = cap.read()
        #time.sleep(1)
        try:
            cv2.imshow('DWebcam',img)
        except:
            print('fail to read the down camera')
            break
        
        #print(usquare)

        k = cv2.waitKey(5) & 0xFF

        if k == ord('d'): #get the coordinate of face
            squ=[]
            pic = img
            coordinate(pic)

        if k == ord('a'): #update the data for model 1
            dsquares=array([allf[3],allf[1],allf[2],allf[0]])
            ttarray=seven_array([allf[3],allf[1],allf[2],allf[0]])
            lsquares=array([ttarray[4],ttarray[5],ttarray[2],ttarray[3]])
            rsquares=array([ttarray[5],ttarray[6],ttarray[3],ttarray[1]])
            #print(ttarray,dsquares,lsquares,rsquares)

        if k == ord('h'): #update the data for model 2
            dsquares=array([allf[3],allf[1],allf[2],allf[0]])
            lsquares=array([allf[4],allf[5],allf[2],allf[3]])
            rsquares=array([allf[5],allf[6],allf[3],allf[1]])

        if k == ord('x'):
            break

        dpts1 = np.float32(dsquares)
        lpts1 = np.float32(lsquares)
        rpts1 = np.float32(rsquares)

        pts2 = np.float32([[0,0],[300,0],[0,300],[300,300]])

        dM = cv2.getPerspectiveTransform(dpts1,pts2)
        lM = cv2.getPerspectiveTransform(lpts1,pts2)
        rM = cv2.getPerspectiveTransform(rpts1,pts2)

        ddst = cv2.warpPerspective(img,dM,(300,300))
        ldst = cv2.warpPerspective(img,lM,(300,300))
        rdst = cv2.warpPerspective(img,rM,(300,300))

        dhsv = cv2.cvtColor(ddst, cv2.COLOR_BGR2HSV)
        lhsv = cv2.cvtColor(ldst, cv2.COLOR_BGR2HSV)
        rhsv = cv2.cvtColor(rdst, cv2.COLOR_BGR2HSV)

        dcolours=[]
        dlcolours=[]
        drcolours=[]
        for i in centlist:
            dcol=display_colorname(ddst, i, dhsv,'yellow','D')
            lcol=display_colorname(ldst, i, lhsv,'orange','B')
            rcol=display_colorname(rdst, i, rhsv,'green','L')
            dcolours.append(dcol)
            dlcolours.append(lcol)
            drcolours.append(rcol)

        vision_params.downface_col = dcolours+drcolours+dlcolours
        #print (vision_params.downface_col)

        cv2.imshow('down',ddst)
        cv2.imshow('downleft',ldst)
        cv2.imshow('downright',rdst)

        #plt.subplot(121),plt.imshow(img),plt.title('Input')
        #plt.subplot(122),plt.imshow(dst),plt.title('Output')
        #plt.show()

    cap.release()

    cv2.destroyAllWindows()

#def poiu2():
    #thr1 = threading.Thread(target=get_downcamera, args=())
    #thr1.start()

