with open('test.txt', "w+") as f:
        #read_data = f.read()
        #f.seek(0)
        #f.truncate()   #清空文件
        f.write('hello worldxxxxx')
        f.close()

