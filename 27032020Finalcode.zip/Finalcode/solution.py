import upcamera
import downcamera
import threading
import vision_params
from collections import Counter
import kociemba
import time


def poiu1():
    thr = threading.Thread(target=upcamera.get_upcamera, args=())
    thr.start()

def poiu2():
    thr1 = threading.Thread(target=downcamera.get_downcamera, args=())
    thr1.start()


poiu1()
time.sleep(0.5)
poiu2()

#thr = threading.Thread(target=upcamera.get_upcamera, args=())
#thr.start()
#thr1 = threading.Thread(target=upcamera.get_upcamera, args=())
#thr1.start()
result = ''
#str ='URRBULBDRBFBFRRLLFULDLFDFFBRUDBDBFRLRDLRLUUUDUDFUBFDBL'


while 1:
    time.sleep(6)
    cube_col = vision_params.downface_col+vision_params.upface_col
    if len(cube_col) == 54:
        count = Counter(cube_col)
        if count['F'] == count['L'] == count['R'] == count['B'] == count['U'] == count['D'] == 9:
            str = "".join(cube_col)
            try:
                result = kociemba.solve(str)
                time.sleep(10)
            except:
                print('Failed to solve the cube')
            print(result)
            print(cube_col)

            with open('test.txt', "w+") as f:
                f.write(result)
                f.close()
    a = input()
    if a == 'x':
        print('break')
        break
    if a == 'r': # read theScramble.txt File
        with open('theScramble.txt', "r+") as f:
            read_data = f.read()
            target_list=list(read_data)
            target_list.remove('[')
            target_list.remove(']')     
            while '"' in target_list:
                target_list.remove('"')
                data = "".join(target_list)
            data_list=[str(x) for x in data.split(',')]
            print(data_list)
            str = "".join(data_list)
            f.close()
            
        try:
            result = kociemba.solve(str)
            time.sleep(10)
        except:
            print('Failed to solve the cube')
        print(result)
        with open('theSolution.txt', "w+") as f:
            f.write(result)
            f.close()
        break
