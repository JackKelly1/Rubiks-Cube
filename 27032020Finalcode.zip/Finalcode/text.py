import kociemba
with open('theScramble.txt', "r+") as f:
    read_data = f.read()
    target_list=list(read_data)
    target_list.remove('[')
    target_list.remove(']')     
    while '"' in target_list:
        target_list.remove('"')
        data = "".join(target_list)
    data_list=[str(x) for x in data.split(',')]
    print(data_list)
    str = "".join(data_list)
    f.close()        
    result = kociemba.solve(str)
    print(result)
with open('theSolution.txt', "w+") as f:
    f.write(result)
    f.close()
