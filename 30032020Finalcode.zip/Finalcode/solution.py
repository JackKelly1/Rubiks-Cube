import upcamera
import downcamera
import threading
import vision_params
from collections import Counter
import kociemba
import time


def poiu1():
    thr = threading.Thread(target=upcamera.get_upcamera, args=())
    thr.start()

def poiu2():
    thr1 = threading.Thread(target=downcamera.get_downcamera, args=())
    thr1.start()


poiu1()
time.sleep(0.5)
poiu2()

#thr = threading.Thread(target=upcamera.get_upcamera, args=())
#thr.start()
#thr1 = threading.Thread(target=upcamera.get_upcamera, args=())
#thr1.start()
result = ''
#str ='URRBULBDRBFBFRRLLFULDLFDFFBRUDBDBFRLRDLRLUUUDUDFUBFDBL'


while 1:
    time.sleep(6)
    cube_col = vision_params.downface_col+vision_params.upface_col
    if len(cube_col) == 54:
        count = Counter(cube_col)
        if count['F'] == count['L'] == count['R'] == count['B'] == count['U'] == count['D'] == 9:
            str = "".join(cube_col)
            try:
                result = kociemba.solve(str)
                time.sleep(10)
            except:
                print('Failed to solve the cube')
            print(result)
            print(cube_col)

            with open('theSolution.txt', "w+") as f:
                f.write(result)
                f.close()
    a = input()
    if a == 'x':
        print('break')
        break

